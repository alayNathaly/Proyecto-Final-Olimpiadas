package com.cog.proyecto_olimpiadas_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoOlimpiadasApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProyectoOlimpiadasApiApplication.class, args);
    }

}
